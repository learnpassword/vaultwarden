The arch-specific directory names follow the arch identifiers used by the Docker official images:

https://github.com/docker-library/official-images/blob/master/README.md#architectures-other-than-amd64
