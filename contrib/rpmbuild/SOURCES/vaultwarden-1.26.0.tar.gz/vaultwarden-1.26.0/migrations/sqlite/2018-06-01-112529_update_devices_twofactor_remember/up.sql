ALTER TABLE devices
    ADD COLUMN
    twofactor_remember TEXT;