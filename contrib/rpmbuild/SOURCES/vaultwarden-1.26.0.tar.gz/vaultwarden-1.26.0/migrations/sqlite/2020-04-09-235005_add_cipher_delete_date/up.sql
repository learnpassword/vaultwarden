ALTER TABLE ciphers
    ADD COLUMN
    deleted_at DATETIME;
