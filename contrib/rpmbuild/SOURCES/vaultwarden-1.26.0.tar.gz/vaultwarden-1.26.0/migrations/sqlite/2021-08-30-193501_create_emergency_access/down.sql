DROP TABLE emergency_access;
